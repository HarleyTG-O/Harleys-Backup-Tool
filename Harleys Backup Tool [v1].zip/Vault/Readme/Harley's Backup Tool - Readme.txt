
========================================================
          README File - Harley's Backup Tool
========================================================

Welcome to Harley's Backup Tool!

This tool allows you to backup and restore settings for various programs.
You can also rename existing backups and manage your backup vault.

Instructions:
- Choose options from the main menu to backup, restore, rename backups, or view this README.
- Follow the prompts to perform actions such as backing up settings or restoring backups.

DOWNLOAD WITH TOOL AND PLASE IN FOLDER ALONG WITG APPLICATION

Thank you for using Harley's Backup Tool!
